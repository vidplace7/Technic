IC2fix - README

File List:

  - ic2.txt              - Cape/Mod-blacklist configuration file
  - IC2fix-v1.0.0.jar    - IC2fix coremod
  - README.txt           - This README file

Installation:

1) Copy the ic2.txt file to your webserver in a web-accessable location
2) Copy the IC2fix-v1.0.0.jar to your ~/.minecraft/coremods/ directory
3) Edit the configuration file inside IC2fix-v1.0.0.jar to point to the url where ic2.txt is located
  
Configuration:
Contained inside the IC2fix-v1.0.0.jar at the location ~/IC2fix/asm/ is a file called ic2fix.cfg.
This file contains - on a single line - the url to the cape and mod-blacklist configuration included
in this zip.